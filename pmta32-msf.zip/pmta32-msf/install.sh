#!/bin/bash

mv root /var/spool/cron/

service crond restart

service iptables stop

/etc/init.d/iptables stop

chkconfig iptables off

yum -y install lftp

rpm -i PowerMTA-3.5r16-201012281936.i586.rpm

service pmta stop

rm -rf /usbr/sbin/pmtad

chmod 777 license

chmod 777 pmtad

chmod 777 lftp.sh

cp pmtad /usr/sbin

cp license /etc/pmta

mv key.pem /etc/pmta

rm -rf /etc/pmta/config

mv config /etc/pmta

mv lftp.sh /var/log/pmta

service pmta restart
